from django.shortcuts import render
import requests
import datetime

def home(request):
    if request.method == "POST" and 'city' in request.POST:
        city = request.POST['city']
    else:
        city = 'indore'

    url = 'https://api.openweathermap.org/data/2.5/weather'
    params = {
        'q': city,
        'appid': '34984dcf3b7003acf41e50883f44ad03',
        'units': 'metric'
    }

    try:
        response = requests.get(url, params=params)
        data = response.json()

        if data.get("cod") != 200:
            raise ValueError("City not found")

        description = data['weather'][0]['description']
        icon = data['weather'][0]['icon']
        temp = data['main']['temp']
        day = datetime.date.today()

        context = {
            'description': description,
            'icon': icon,
            'temp': temp,
            'day': day,
            'city': city
        }

    except Exception as e:
        context = {
            'description': "City not found!",
            'icon': "01d",  # fallback icon
            'temp': "N/A",
            'day': datetime.date.today(),
            'city': city
        }

    return render(request, 'wheather/index.html', context)
