from django.apps import AppConfig


class WheatherappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wheatherapp'
